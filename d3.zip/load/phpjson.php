<?php
	$json='{"name":"liu","name":"xiang"}';
	//$result["name"]="liu1";
//	array_push($result[0],array("name" => "xiang"));
	//var_dump(json_decode($json,true));
	$json->json;
?>